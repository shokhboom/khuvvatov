![image](olx-spider.png)

# OLX.UZ веб-ўргимчаги
OLX.UZ веб-сайтидан "керакли" маълумотларни йиғамиз.

Ўрнатиш тартиби
---

```shell
  $ pip install -r requirements.txt
```

Маълумотлар йиғиш
---

- Эълон берувчиларнинг телефон рақамлари
- Товар ҳақида маълумот (матн ва расм)

Телефон рақамларни йиғиш
---

```shell
  $ scrapy crawl phone-number-crawler
```
